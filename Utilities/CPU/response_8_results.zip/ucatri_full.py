"""Python mirror of ucatri_sim_r2022.m: same nine methods, same experiments,
same CSV columns and the same seven figures. Used to produce the results here,
because MATLAB is not available in this environment.
Run: python ucatri_full.py [snr|freq|spread|T|plot|all]"""
import numpy as np, sys, os, csv, zlib
from scipy.special import jv

C0 = 299792458.0
NAMES = ['M1', 'M2', 'CIcos', 'APCI', 'SSMUSIC', 'EP', 'UC', 'P1', 'P2']
OUT = 'results'

def params(**kw):
    P = dict(N=9, R=0.50, f=0.7e9, T=32, trials=500, gridDeg=0.1, L=256, nNewton=3, okDeg=5)
    P.update(kw); return P

def geometry(P):
    N = P['N']; G = dict(N=N, K=(N-1)//2)
    G['gam'] = 2*np.pi*np.arange(N)/N
    G['beta'] = 2*np.pi*P['R']*P['f']/C0
    K = G['K']; G['tri'] = np.array([[0, k, N-k] for k in range(1, K+1)])
    G['pairs'] = [(0, 1), (0, 2), (1, 2)]
    M = int(np.ceil(2.2*G['beta']+12)); m = np.arange(-M, M+1); G['m'] = m
    G['thg'] = np.deg2rad(np.arange(0, 360, P['gridDeg']))
    Ag = np.exp(1j*G['beta']*np.cos(G['thg'][:, None]-G['gam'][None, :])); G['Ag'] = Ag
    G['Aref'] = Ag*np.conj(Ag[:, :1])
    C = []; Ap = []
    for k in range(K):
        for i, l in G['pairs']:
            ei, el = G['tri'][k, i], G['tri'][k, l]; gi, gl = G['gam'][ei], G['gam'][el]
            b = 2*G['beta']*np.sin((gl-gi)/2); al = (gi+gl)/2+np.pi/2
            C.append((1j**m)*jv(m, b)*np.exp(-1j*m*al)); Ap.append(Ag[:, ei]*np.conj(Ag[:, el]))
    G['C'] = np.array(C); G['Apair'] = np.array(Ap).T
    return G

def steer(G, th, idx): return np.exp(1j*G['beta']*np.cos(th-G['gam'][idx]))
def dwell(G, th, rho, idx, xi, nu, T, rng):
    a = steer(G, th, np.asarray(idx)); m = len(idx)
    s = np.sqrt(rho*xi/2)*(rng.standard_normal(T)+1j*rng.standard_normal(T))
    n = np.sqrt(nu/2)*(rng.standard_normal((m, T))+1j*rng.standard_normal((m, T)))
    return np.outer(a, s)+n

def ci_search(G, z, metric):
    g = G['Aref']@np.conj(z); i = np.argmax(np.real(g) if metric == 'real' else np.abs(g)); return G['thg'][i]
def ssmusic(G, Rk):
    Pm = np.zeros(len(G['thg']))
    for k in range(G['K']):
        _, V = np.linalg.eigh((Rk[k]+Rk[k].conj().T)/2); En = V[:, :2]
        Pm += np.sum(np.abs(G['Ag'][:, G['tri'][k]]@np.conj(En))**2, 1)
    return G['thg'][np.argmin(Pm)]
def p1(G, P, Rk, w):
    m, L = G['m'], P['L']; Gm = np.zeros(len(m), complex); r = 0
    for k in range(G['K']):
        for i, l in G['pairs']: Gm += w[k]*Rk[k][i, l]*G['C'][r]; r += 1
    H = Gm+np.conj(Gm[::-1]); Hf = np.zeros(L, complex); Hf[np.mod(m, L)] = H
    Jg = np.real(np.fft.ifft(Hf))*L; l = int(np.argmax(Jg)); d = 2*np.pi/L
    y = Jg[np.mod([l-1, l, l+1], L)]; den = y[0]-2*y[1]+y[2]
    th = (l+(0.5*(y[0]-y[2])/den if den != 0 else 0))*d
    for _ in range(P['nNewton']):
        e = np.exp(1j*m*th); J1 = np.real(np.sum(1j*m*H*e)); J2 = np.real(-np.sum(m**2*H*e))
        if J2 < 0: th -= np.clip(J1/J2, -d/2, d/2)
    return th % (2*np.pi)
def p2(G, Rk, w):
    U = V = 0.0; num = np.zeros(2); den = np.zeros(2)
    for k in range(G['K']):
        _, Ev = np.linalg.eigh((Rk[k]+Rk[k].conj().T)/2); u = Ev[:, -1]
        u = u*np.conj(u[0])/abs(u[0]); ph = np.angle(u[1:3]); gk = G['gam'][k+1]
        if k > 0:
            pred = np.array([(np.cos(gk)-1)*U+np.sin(gk)*V, (np.cos(gk)-1)*U-np.sin(gk)*V])
            ph = ph+2*np.pi*np.round((pred-ph)/(2*np.pi))
        sk = (ph[0]+ph[1])/2; dk = (ph[0]-ph[1])/2
        num += w[k]*np.array([(np.cos(gk)-1)*sk, np.sin(gk)*dk])
        den += w[k]*np.array([(np.cos(gk)-1)**2, np.sin(gk)**2])
        U = num[0]/den[0] if den[0] > 0 else 0; V = num[1]/den[1] if den[1] > 0 else 0
    return np.arctan2(V, U) % (2*np.pi)
def eig_w(Rk):
    w = []
    for R in Rk:
        l = np.sort(np.linalg.eigvalsh((R+R.conj().T)/2))[::-1]
        s2 = max((l[1]+l[2])/2, 1e-300); rh = max((l[0]-s2)/(3*s2), 0); w.append(rh/(s2*(1+3*rh)))
    return np.array(w)
def crb(G, th, rho, T, scheme):
    sets = list(G['tri']) if scheme == 'tri' else [np.array([0, n]) for n in range(1, G['N'])]
    J = 0
    for idx in sets:
        m = len(idx); sn = np.sin(th-G['gam'][idx])
        J += 2*T*m*rho**2/(1+m*rho)*G['beta']**2*(np.sum(sn**2)-np.sum(sn)**2/m)
    return 1/J

def mc_point(P, snrdB, xiSpread=0, nuSpread=0, seed=0):
    rng = np.random.default_rng(seed); G = geometry(P); rho = 10**(snrdB/10); N, K, T = P['N'], G['K'], P['T']
    err = np.zeros((P['trials'], 9)); c = np.zeros((P['trials'], 2))
    fl = lambda: (10**((rng.random()-0.5)*xiSpread/10), 10**((rng.random()-0.5)*nuSpread/10))
    for t in range(P['trials']):
        th = 2*np.pi*rng.random(); e = np.zeros(9)
        z = np.zeros(N, complex); z[0] = 1
        for n in range(1, N):
            xi, nu = fl(); X = dwell(G, th, rho, [0, n], xi, nu, T, rng)
            r = X[1]@X[0].conj()/T; z[n] = r/abs(r)
        e[0] = ci_search(G, z, 'abs')
        Rk = []; zl = np.zeros(N, complex); zl[0] = 1; ze = zl.copy(); zp = []
        for k in range(K):
            xi, nu = fl(); X = dwell(G, th, rho, G['tri'][k], xi, nu, T, rng); R = X@X.conj().T/T; Rk.append(R)
            zl[k+1] = R[1, 0]/abs(R[1, 0]); zl[N-k-1] = R[2, 0]/abs(R[2, 0])
            _, Ev = np.linalg.eigh((R+R.conj().T)/2); u = Ev[:, -1]*np.conj(Ev[0, -1])
            ze[k+1] = u[1]/abs(u[1]); ze[N-k-1] = u[2]/abs(u[2])
            for i, l in G['pairs']: zp.append(R[i, l]/abs(R[i, l]))
        e[1] = ci_search(G, zl, 'abs'); e[2] = ci_search(G, zl, 'real')
        e[3] = G['thg'][np.argmax(np.real(G['Apair']@np.conj(np.array(zp))))]
        e[4] = ssmusic(G, Rk); e[5] = ci_search(G, ze, 'abs')
        w = eig_w(Rk); e[6] = p1(G, P, Rk, np.ones(K)); e[7] = p1(G, P, Rk, w); e[8] = p2(G, Rk, w)
        err[t] = np.rad2deg(np.angle(np.exp(1j*(e-th)))); c[t] = [crb(G, th, rho, T, 'two'), crb(G, th, rho, T, 'tri')]
    return (np.sqrt(np.mean(err**2, 0)), np.mean(np.abs(err) < P['okDeg'], 0),
            np.rad2deg(np.sqrt(np.mean(c[:, 0]))), np.rad2deg(np.sqrt(np.mean(c[:, 1]))))

def sweep(fname, xname, xs, fun):
    hdr = [xname]+[n+'_rmse' for n in NAMES]+[n+'_pc' for n in NAMES]+['CRB2', 'CRB3']
    with open(os.path.join(OUT, fname), 'w', newline='') as fh:
        wr = csv.writer(fh); wr.writerow(hdr)
        for j, x in enumerate(xs):
            r, pc, c2, c3 = fun(x, zlib.crc32(fname.encode()) % 100000 * 1000 + j)
            wr.writerow([f'{x:.6g}']+[f'{v:.5g}' for v in [*r, *pc, c2, c3]]); fh.flush(); print(fname, x, flush=True)

def run(which):
    os.makedirs(OUT, exist_ok=True); P = params()
    if which in ('snr', 'all'):
        sweep('fig2_3_snr.csv', 'SNR_dB', np.arange(-12, 17, 2), lambda x, s: mc_point(P, x, seed=s))
    if which in ('freq', 'all'):
        sweep('fig4_low.csv', 'f_GHz', np.linspace(0.1, 0.8, 16), lambda x, s: mc_point(params(R=0.50, f=x*1e9), 0, seed=s))
        sweep('fig4_high.csv', 'f_GHz', np.linspace(0.8, 2.5, 16), lambda x, s: mc_point(params(R=0.15, f=x*1e9), 0, seed=s))
    if which in ('spread', 'all'):
        P5 = params(trials=4000)   # rare outliers dominate the RMSE here, so use more trials
        sweep('fig5_signal.csv', 'spread_dB', np.arange(0, 13, 3), lambda x, s: mc_point(P5, -2, xiSpread=x, seed=s))
        sweep('fig5_noise.csv', 'spread_dB', np.arange(0, 13, 3), lambda x, s: mc_point(P5, -2, nuSpread=x, seed=s))
    if which in ('T', 'all'):
        sweep('fig6_T.csv', 'T', [8, 16, 32, 64, 128, 256], lambda x, s: mc_point(params(T=int(x)), -4, seed=s))

if __name__ == '__main__':
    run(sys.argv[1] if len(sys.argv) > 1 else 'all')
