%% ucatri_sim_r2022.m
% Monte Carlo study of the three-channel isosceles-triangle correlative
% interferometer, MATLAB R2022a/R2022b.
%
% Methods compared on the same dwells in every trial:
%   M1      two-channel CI, N-1 dwells                       (paper, Sec. IV)
%   M2      three-channel triangle CI, leg phases, |corr|   (paper, Sec. IV)
%   CIcos   triangle CI with the cosine metric Re{corr}     (Qin et al. [8])
%   APCI    all-pair phase CI: legs and base of each triangle
%   SSMUSIC subarray MUSIC, triangle noise subspaces combined incoherently [10]
%   EP      eigen-phase CI
%   UC      covariance-domain CI with equal weights
%   P1      proposed: weighted covariance CI, inverse FFT + Newton
%   P2      proposed: closed-form sum/difference estimator
%
% Output (folder 'results' next to this file):
%   CSV files : fig2_3_snr.csv, fig4_low.csv, fig4_high.csv,
%               fig5_signal.csv, fig5_noise.csv, fig6_T.csv
%   Figures   : fig2 ... fig7 as .png (200 dpi) and .fig
% Each CSV has the columns  x, <method>_rmse (deg), <method>_pc (share of
% bearings within 5 deg), CRB2 and CRB3 (azimuth-averaged root CRB, deg).
%
% Run time with 500 trials per point (4,000 for Fig. 5): roughly 15-40 minutes
% on one core.
% For a quick check, set QUICK = true (100 trials per point).
%
% To redraw the figures from existing CSV files without simulating again,
% set REPLOT_ONLY = true.

clear; close all; clc;

QUICK       = false;
REPLOT_ONLY = false;

P = default_params();
if QUICK, P.trials = 100; end
rng(1, 'twister');

outDir = fullfile(pwd, 'results');
if ~exist(outDir, 'dir'), mkdir(outDir); end

files = struct('snr', 'fig2_3_snr.csv', 'low', 'fig4_low.csv', 'high', 'fig4_high.csv', ...
               'sig', 'fig5_signal.csv', 'noi', 'fig5_noise.csv', 'T', 'fig6_T.csv');

if ~REPLOT_ONLY
    tic;
    % ---- Figs. 2, 3 and 7: SNR sweep at 0.7 GHz ----
    Tsnr = run_sweep('SNR_dB', -12:2:16, @(x) mc_point(P, x, struct()));
    writetable(Tsnr, fullfile(outDir, files.snr));

    % ---- Fig. 4: frequency sweep at 0 dB, both arrays ----
    Tlow  = run_sweep('f_GHz', linspace(0.1, 0.8, 16), ...
                      @(x) mc_point(setf(P, 0.50, x*1e9), 0, struct()));
    Thigh = run_sweep('f_GHz', linspace(0.8, 2.5, 16), ...
                      @(x) mc_point(setf(P, 0.15, x*1e9), 0, struct()));
    writetable(Tlow,  fullfile(outDir, files.low));
    writetable(Thigh, fullfile(outDir, files.high));

    % ---- Figs. 5 and 7: dwell-to-dwell fluctuations at -2 dB ----
    % Rare large outliers dominate the RMSE here, so this sweep uses 8x more trials.
    P5 = P;  P5.trials = 8*P.trials;
    Tsig = run_sweep('spread_dB', 0:3:12, @(x) mc_point(P5, -2, struct('xiSpreadDB', x)));
    Tnoi = run_sweep('spread_dB', 0:3:12, @(x) mc_point(P5, -2, struct('nuSpreadDB', x)));
    writetable(Tsig, fullfile(outDir, files.sig));
    writetable(Tnoi, fullfile(outDir, files.noi));

    % ---- Fig. 6: snapshots per dwell at -4 dB ----
    TT = run_sweep('T', [8 16 32 64 128 256], @(x) mc_point(setT(P, x), -4, struct()));
    writetable(TT, fullfile(outDir, files.T));
    fprintf('Simulation finished in %.1f min.\n', toc/60);
else
    Tsnr  = readtable(fullfile(outDir, files.snr));
    Tlow  = readtable(fullfile(outDir, files.low));
    Thigh = readtable(fullfile(outDir, files.high));
    Tsig  = readtable(fullfile(outDir, files.sig));
    Tnoi  = readtable(fullfile(outDir, files.noi));
    TT    = readtable(fullfile(outDir, files.T));
end

plot_all(outDir, Tsnr, Tlow, Thigh, Tsig, Tnoi, TT);
fprintf('CSV files and figures written to %s\n', outDir);


%% =====================================================================
%% Local functions (must stay at the end of the script file)
%% =====================================================================

%% ---------- 1. Parameters ----------
function P = default_params()
    P.N       = 9;          % elements (odd)
    P.R       = 0.50;       % array radius, m (low band)
    P.f       = 0.7e9;      % frequency, Hz
    P.T       = 32;         % snapshots per dwell
    P.trials  = 500;        % Monte Carlo trials per point
    P.gridDeg = 0.1;        % search grid of the grid-search methods, deg
    P.L       = 256;        % FFT length of P1
    P.nNewton = 3;          % Newton steps of P1
    P.okDeg   = 5;          % correct-DF threshold, deg
    P.c       = 299792458;
end

function n = method_names()
    n = {'M1', 'M2', 'CIcos', 'APCI', 'SSMUSIC', 'EP', 'UC', 'P1', 'P2'};
end

function P = setf(P, R, f), P.R = R; P.f = f; end
function P = setT(P, T),    P.T = T;          end

%% ---------- 2. Array, switching and reference tables ----------
function G = geometry(P)
    G.N    = P.N;
    G.gam  = 2*pi*(0:P.N-1)/P.N;                          % element azimuths
    G.beta = 2*pi*P.R*P.f/P.c;                            % 2*pi*R/lambda
    G.K    = (P.N-1)/2;
    G.tri  = [zeros(G.K,1), (1:G.K)', (P.N-(1:G.K))'];    % [0 k N-k], 0-based
    G.pairs = [1 2; 1 3; 2 3];                            % local pairs of a triangle
    G.M    = ceil(2.2*G.beta + 12);                       % phase-mode truncation
    m      = -G.M:G.M;
    G.m    = m;
    G.thg  = (0:P.gridDeg:360-P.gridDeg)*pi/180;          % search grid, rad
    G.Ag   = exp(1j*G.beta*cos(G.thg(:) - G.gam));        % Ng x N element responses
    G.Aref = G.Ag .* conj(G.Ag(:,1));                     % referenced to element 0
    G.C     = zeros(3*G.K, numel(m));                     % phase-mode table (P1)
    G.Apair = zeros(numel(G.thg), 3*G.K);                 % pair reference (APCI)
    r = 0;
    for k = 1:G.K
        for p = 1:3
            ei = G.tri(k, G.pairs(p,1)) + 1;
            el = G.tri(k, G.pairs(p,2)) + 1;
            gi = G.gam(ei);  gl = G.gam(el);
            b  = 2*G.beta*sin((gl-gi)/2);                 % baseline length, rad
            al = (gi+gl)/2 + pi/2;                        % baseline broadside
            r  = r + 1;
            G.C(r,:)     = (1j.^m) .* besselj(m, b) .* exp(-1j*m*al);
            G.Apair(:,r) = G.Ag(:,ei) .* conj(G.Ag(:,el));
        end
    end
end

function a = steer(G, th, idx)      % centre-referenced response, idx 0-based
    a = exp(1j*G.beta*cos(th - G.gam(idx+1))).';
end

%% ---------- 3. Data of one dwell ----------
function X = dwell_data(G, th, rho, idx, xi, nu, T)
    m = numel(idx);
    a = steer(G, th, idx);
    s = sqrt(rho*xi/2) * (randn(1,T) + 1j*randn(1,T));
    n = sqrt(nu/2)     * (randn(m,T) + 1j*randn(m,T));
    X = a*s + n;
end

function [xi, nu] = fluct(opt)      % per-dwell signal and noise factors
    xi = 10^((rand-0.5)*opt.xiSpreadDB/10);
    nu = 10^((rand-0.5)*opt.nuSpreadDB/10);
end

%% ---------- 4. Estimators ----------
function th = ci_search(G, z, metric)      % conventional CI on the grid
    g = G.Aref * conj(z(:));
    if strcmp(metric, 'real')
        [~, i] = max(real(g));
    else
        [~, i] = max(abs(g));
    end
    th = G.thg(i);
end

function th = ssmusic(G, Rk)                % subarray MUSIC, incoherent
    Pm = zeros(numel(G.thg), 1);
    for k = 1:G.K
        R = (Rk(:,:,k) + Rk(:,:,k)')/2;
        [V, D] = eig(R);
        [~, ix] = sort(real(diag(D)), 'ascend');
        En = V(:, ix(1:2));                         % noise subspace
        A  = G.Ag(:, G.tri(k,:) + 1);
        Pm = Pm + sum(abs(A*conj(En)).^2, 2);
    end
    [~, i] = min(Pm);
    th = G.thg(i);
end

function [th, conf] = p1_estimate(G, P, Rk, w)
    Gm = zeros(1, numel(G.m));  r = 0;
    for k = 1:G.K
        for p = 1:3
            r = r + 1;
            Gm = Gm + w(k)*Rk(G.pairs(p,1), G.pairs(p,2), k)*G.C(r,:);
        end
    end
    H  = Gm + conj(fliplr(Gm));                     % H_m = G_m + conj(G_-m)
    Hf = zeros(1, P.L);
    Hf(mod(G.m, P.L) + 1) = H;
    Jg = real(ifft(Hf))*P.L;                        % J(2*pi*l/L), l = 0..L-1
    [~, l] = max(Jg);
    d  = 2*pi/P.L;
    y  = Jg(mod(l-2:l, P.L) + 1);                   % neighbours of the peak
    dl = 0.5*(y(1)-y(3))/(y(1)-2*y(2)+y(3));        % parabolic vertex
    if ~isfinite(dl), dl = 0; end
    th = (l-1+dl)*d;
    for it = 1:P.nNewton                            % Newton on the analytic J
        e  = exp(1j*G.m*th);
        J1 = real(sum(1j*G.m.*H.*e));
        J2 = real(-sum(G.m.^2.*H.*e));
        if J2 < 0
            th = th - max(min(J1/J2, d/2), -d/2);
        end
    end
    th   = mod(th, 2*pi);
    conf = real(sum(H.*exp(1j*G.m*th))) / max(real(sum(abs(H))), eps);
end

function th = p2_estimate(G, Rk, w)
    U = 0; V = 0; num = zeros(2,1); den = zeros(2,1);
    for k = 1:G.K
        [Ev, Dv] = eig((Rk(:,:,k) + Rk(:,:,k)')/2);
        [~, i] = max(real(diag(Dv)));
        u  = Ev(:,i);  u = u*conj(u(1))/abs(u(1));
        ph = angle(u(2:3));
        gk = G.gam(k+1);
        if k > 1                                    % unwrap toward the prediction
            pred = [(cos(gk)-1)*U + sin(gk)*V; (cos(gk)-1)*U - sin(gk)*V];
            ph = ph + 2*pi*round((pred-ph)/(2*pi));
        end
        sk = (ph(1)+ph(2))/2;  dk = (ph(1)-ph(2))/2;
        num = num + w(k)*[(cos(gk)-1)*sk; sin(gk)*dk];
        den = den + w(k)*[(cos(gk)-1)^2;  sin(gk)^2];
        if den(1) > 0, U = num(1)/den(1); end
        if den(2) > 0, V = num(2)/den(2); end
    end
    th = mod(atan2(V, U), 2*pi);
end

function [w, rhoh, s2] = eig_weights(Rk)
    K = size(Rk,3);  w = zeros(K,1);  rhoh = w;  s2 = w;
    for k = 1:K
        l = sort(real(eig((Rk(:,:,k) + Rk(:,:,k)')/2)), 'descend');
        s2(k)   = max((l(2)+l(3))/2, realmin);
        rhoh(k) = max((l(1)-s2(k))/(3*s2(k)), 0);
        w(k)    = rhoh(k)/(s2(k)*(1+3*rhoh(k)));
    end
end

%% ---------- 5. Cramer-Rao bound (rad^2), elevation 0 ----------
function c = crb(G, th, rho, T, scheme)
    if strcmp(scheme, 'tri')
        sets = num2cell(G.tri, 2);
    else
        sets = arrayfun(@(n) [0 n], 1:G.N-1, 'UniformOutput', false);
    end
    Jt = 0;
    for k = 1:numel(sets)
        idx = sets{k};  m = numel(idx);
        sn  = sin(th - G.gam(idx+1));
        Jt  = Jt + 2*T*m*rho^2/(1+m*rho) * G.beta^2 * (sum(sn.^2) - sum(sn)^2/m);
    end
    c = 1/Jt;
end

%% ---------- 6. One Monte Carlo point ----------
function out = mc_point(P, snrdB, opt)
    G = geometry(P);  rho = 10^(snrdB/10);
    if ~isfield(opt, 'xiSpreadDB'), opt.xiSpreadDB = 0; end
    if ~isfield(opt, 'nuSpreadDB'), opt.nuSpreadDB = 0; end
    nm  = numel(method_names());
    err = nan(P.trials, nm);  c = zeros(P.trials, 2);  e = zeros(1, nm);
    for t = 1:P.trials
        th = 2*pi*rand;

        % --- M1: two channels, N-1 dwells
        z = zeros(P.N,1);  z(1) = 1;
        for n = 1:P.N-1
            [xi, nu] = fluct(opt);
            X = dwell_data(G, th, rho, [0 n], xi, nu, P.T);
            r = X(2,:)*X(1,:)'/P.T;  z(n+1) = r/abs(r);
        end
        e(1) = ci_search(G, z, 'abs');

        % --- triangle dwells, shared by all other methods
        Rk = zeros(3,3,G.K);  zl = zeros(P.N,1);  zl(1) = 1;  ze = zl;
        zp = zeros(3*G.K,1);  r = 0;
        for k = 1:G.K
            [xi, nu] = fluct(opt);
            X = dwell_data(G, th, rho, G.tri(k,:), xi, nu, P.T);
            R = X*X'/P.T;  Rk(:,:,k) = R;
            zl(k+1)     = R(2,1)/abs(R(2,1));           % leg phases
            zl(P.N-k+1) = R(3,1)/abs(R(3,1));
            [Ev, Dv] = eig((R+R')/2);  [~, i] = max(real(diag(Dv)));
            u = Ev(:,i)*conj(Ev(1,i));                  % eigen-phases
            ze(k+1) = u(2)/abs(u(2));  ze(P.N-k+1) = u(3)/abs(u(3));
            for p = 1:3                                 % all three pair phases
                r = r + 1;  v = R(G.pairs(p,1), G.pairs(p,2));  zp(r) = v/abs(v);
            end
        end
        e(2) = ci_search(G, zl, 'abs');                 % M2
        e(3) = ci_search(G, zl, 'real');                % CIcos
        [~, i] = max(real(G.Apair*conj(zp)));  e(4) = G.thg(i);   % APCI
        e(5) = ssmusic(G, Rk);                          % SSMUSIC
        e(6) = ci_search(G, ze, 'abs');                 % EP
        w = eig_weights(Rk);
        e(7) = p1_estimate(G, P, Rk, ones(G.K,1));      % UC
        e(8) = p1_estimate(G, P, Rk, w);                % P1
        e(9) = p2_estimate(G, Rk, w);                   % P2

        err(t,:) = angle(exp(1j*(e - th)))*180/pi;
        c(t,:)   = [crb(G, th, rho, P.T, 'two'), crb(G, th, rho, P.T, 'tri')];
    end
    out.rmse = sqrt(mean(err.^2, 1));
    out.pc   = mean(abs(err) < P.okDeg, 1);
    out.crb2 = sqrt(mean(c(:,1)))*180/pi;
    out.crb3 = sqrt(mean(c(:,2)))*180/pi;
end

%% ---------- 7. Sweeps and CSV tables ----------
function Tb = run_sweep(xname, xs, fun)
    names = method_names();  nm = numel(names);
    M = zeros(numel(xs), 1 + 2*nm + 2);
    for j = 1:numel(xs)
        o = fun(xs(j));
        M(j,:) = [xs(j), o.rmse, o.pc, o.crb2, o.crb3];
        fprintf('%-10s = %-8g done\n', xname, xs(j));
    end
    vn = [{xname}, strcat(names, '_rmse'), strcat(names, '_pc'), {'CRB2', 'CRB3'}];
    Tb = array2table(M, 'VariableNames', vn);
end

%% ---------- 8. Figures ----------
function S = method_styles()
    S.M1      = struct('ls','--o','c',[0.62 0.62 0.62],'lw',1.2,'lab','M1: 2-ch CI');
    S.M2      = struct('ls','-s', 'c',[0.45 0.45 0.45],'lw',1.2,'lab','M2: 3-ch triangle CI');
    S.CIcos   = struct('ls','--s','c',[0.69 0.48 0.63],'lw',1.2,'lab','CI, cosine metric [8]');
    S.APCI    = struct('ls','-^', 'c',[0.35 0.63 0.31],'lw',1.2,'lab','All-pair phase CI');
    S.SSMUSIC = struct('ls','-d', 'c',[0.95 0.56 0.17],'lw',1.2,'lab','Subarray MUSIC [10]');
    S.EP      = struct('ls',':v', 'c',[0.55 0.55 0.55],'lw',1.2,'lab','Eigen-phase CI');
    S.UC      = struct('ls','-.x','c',[0.30 0.30 0.30],'lw',1.2,'lab','Unweighted covariance CI');
    S.P1      = struct('ls','-o', 'c',[0.12 0.37 0.75],'lw',2.2,'lab','P1, proposed');
    S.P2      = struct('ls',':o', 'c',[0.20 0.65 0.85],'lw',1.4,'lab','P2, closed form');
end

function plot_methods(ax, x, Tb, list, suffix, scale, showLegend)
    S = method_styles();
    if showLegend, vis = 'on'; else, vis = 'off'; end
    for i = 1:numel(list)
        s = S.(list{i});
        plot(ax, x, scale*Tb.([list{i} suffix]), s.ls, 'Color', s.c, 'LineWidth', s.lw, ...
             'MarkerSize', 5, 'MarkerFaceColor', s.c, 'DisplayName', s.lab, ...
             'HandleVisibility', vis);
    end
end

function ax = new_axes(f, ylog)
    ax = axes(f);  hold(ax, 'on');  grid(ax, 'on');  box(ax, 'on');
    if ylog, set(ax, 'YScale', 'log'); end
    set(ax, 'FontSize', 10);
end

function save_fig(f, outDir, name)
    exportgraphics(f, fullfile(outDir, [name '.png']), 'Resolution', 200);
    savefig(f, fullfile(outDir, [name '.fig']));
end

function plot_all(outDir, Tsnr, Tlow, Thigh, Tsig, Tnoi, TT)
    crbStyle = {'k--', 'LineWidth', 1.2};
    allm = {'M1','M2','CIcos','APCI','SSMUSIC','P1'};

    % Fig. 2: RMSE versus SNR
    f = figure('Name', 'Fig. 2', 'Color', 'w', 'Position', [80 80 760 500]);
    ax = new_axes(f, true);
    plot_methods(ax, Tsnr.SNR_dB, Tsnr, allm, '_rmse', 1, true);
    plot(ax, Tsnr.SNR_dB, Tsnr.CRB2, ':', 'Color', [0.4 0.4 0.4], 'LineWidth', 1.2, 'DisplayName', 'CRB, 2-ch');
    plot(ax, Tsnr.SNR_dB, Tsnr.CRB3, crbStyle{:}, 'DisplayName', 'CRB, triangles');
    xlabel(ax, 'Per-element SNR (dB)');  ylabel(ax, 'Azimuth RMSE (deg)');
    title(ax, 'Fig. 2. Azimuth RMSE versus SNR (f = 0.7 GHz, N = 9, T = 32)');
    legend(ax, 'Location', 'northeast');
    save_fig(f, outDir, 'fig2_rmse_vs_snr');

    % Fig. 3: correct-DF rate versus SNR
    f = figure('Name', 'Fig. 3', 'Color', 'w', 'Position', [100 100 760 500]);
    ax = new_axes(f, false);
    plot_methods(ax, Tsnr.SNR_dB, Tsnr, allm, '_pc', 100, true);
    yline(ax, 95, ':', '95% correct', 'Color', [0.4 0.4 0.4], 'HandleVisibility', 'off');
    xlim(ax, [-12 2]);  ylim(ax, [0 102]);
    xlabel(ax, 'Per-element SNR (dB)');  ylabel(ax, 'Correct DF, error < 5 deg (%)');
    title(ax, 'Fig. 3. Share of correct bearings versus SNR');
    legend(ax, 'Location', 'southeast');
    save_fig(f, outDir, 'fig3_correct_df_vs_snr');

    % Fig. 4: RMSE across 0.1-2.5 GHz
    f = figure('Name', 'Fig. 4', 'Color', 'w', 'Position', [120 120 860 500]);
    ax = new_axes(f, true);  set(ax, 'XScale', 'log');
    fm = {'M2', 'APCI', 'P1', 'P2'};
    plot_methods(ax, Tlow.f_GHz,  Tlow,  fm, '_rmse', 1, true);
    plot_methods(ax, Thigh.f_GHz, Thigh, fm, '_rmse', 1, false);
    plot(ax, Tlow.f_GHz,  Tlow.CRB3,  crbStyle{:}, 'DisplayName', 'CRB, triangles');
    plot(ax, Thigh.f_GHz, Thigh.CRB3, crbStyle{:}, 'HandleVisibility', 'off');
    xline(ax, 0.8, ':', 'Array change at 0.8 GHz', 'HandleVisibility', 'off');
    ylim(ax, [0.1 10]);  xlim(ax, [0.1 2.5]);
    xticks(ax, [0.1 0.2 0.3 0.5 0.8 1 1.5 2 2.5]);
    xlabel(ax, 'Frequency (GHz)');  ylabel(ax, 'Azimuth RMSE at 0 dB (deg)');
    title(ax, 'Fig. 4. RMSE across 0.1-2.5 GHz (R = 0.50 m below 0.8 GHz, 0.15 m above)');
    legend(ax, 'Location', 'southwest');
    save_fig(f, outDir, 'fig4_rmse_vs_frequency');

    % Fig. 5: dwell-to-dwell fluctuations
    f = figure('Name', 'Fig. 5', 'Color', 'w', 'Position', [140 140 1080 460]);
    tl = tiledlayout(f, 1, 2, 'TileSpacing', 'compact');
    sm = {'M2', 'EP', 'APCI', 'SSMUSIC', 'UC', 'P1'};
    ax = nexttile(tl);  hold(ax,'on'); grid(ax,'on'); box(ax,'on'); set(ax,'YScale','log');
    plot_methods(ax, Tsig.spread_dB, Tsig, sm, '_rmse', 1, true);
    plot(ax, Tsig.spread_dB, Tsig.CRB3, crbStyle{:}, 'DisplayName', 'CRB, triangles');
    xlabel(ax, 'Signal-power spread between dwells (dB)');  ylabel(ax, 'RMSE (deg)');
    title(ax, '(a) Signal-power spread');  legend(ax, 'Location', 'northwest');
    ax = nexttile(tl);  hold(ax,'on'); grid(ax,'on'); box(ax,'on'); set(ax,'YScale','log');
    plot_methods(ax, Tnoi.spread_dB, Tnoi, sm, '_rmse', 1, false);
    plot(ax, Tnoi.spread_dB, Tnoi.CRB3, crbStyle{:}, 'HandleVisibility', 'off');
    xlabel(ax, 'Noise-floor spread between dwells (dB)');
    title(ax, '(b) Noise-floor spread');
    title(tl, 'Fig. 5. Robustness to dwell-to-dwell fluctuations (-2 dB mean SNR, 0.7 GHz)');
    save_fig(f, outDir, 'fig5_fluctuations');

    % Fig. 6: snapshots per dwell
    f = figure('Name', 'Fig. 6', 'Color', 'w', 'Position', [160 160 760 500]);
    ax = new_axes(f, true);  set(ax, 'XScale', 'log');
    plot_methods(ax, TT.T, TT, {'M1','M2','APCI','SSMUSIC','P1'}, '_rmse', 1, true);
    plot(ax, TT.T, TT.CRB3, crbStyle{:}, 'DisplayName', 'CRB, triangles');
    xticks(ax, [8 16 32 64 128 256]);
    xlabel(ax, 'Snapshots per dwell T');  ylabel(ax, 'Azimuth RMSE at -4 dB (deg)');
    title(ax, 'Fig. 6. RMSE versus snapshots per dwell');
    legend(ax, 'Location', 'northeast');
    save_fig(f, outDir, 'fig6_rmse_vs_snapshots');

    % Fig. 7: P1 against four three-channel baselines (reviewer question 1)
    f = figure('Name', 'Fig. 7', 'Color', 'w', 'Position', [180 180 1380 440]);
    tl = tiledlayout(f, 1, 3, 'TileSpacing', 'compact');
    cm = {'M2', 'CIcos', 'APCI', 'SSMUSIC', 'P1'};
    ax = nexttile(tl);  hold(ax,'on'); grid(ax,'on'); box(ax,'on'); set(ax,'YScale','log');
    plot_methods(ax, Tsnr.SNR_dB, Tsnr, cm, '_rmse', 1, true);
    plot(ax, Tsnr.SNR_dB, Tsnr.CRB3, crbStyle{:}, 'DisplayName', 'CRB, triangles');
    xlabel(ax, 'Per-element SNR (dB)');  ylabel(ax, 'RMSE (deg)');
    title(ax, '(a) RMSE versus SNR');  legend(ax, 'Location', 'northeast');
    ax = nexttile(tl);  hold(ax,'on'); grid(ax,'on'); box(ax,'on');
    plot_methods(ax, Tsnr.SNR_dB, Tsnr, cm, '_pc', 100, false);
    yline(ax, 95, ':', 'HandleVisibility', 'off');  xlim(ax, [-12 2]);
    xlabel(ax, 'Per-element SNR (dB)');  ylabel(ax, 'Correct DF (%)');
    title(ax, '(b) Share within 5 deg');
    ax = nexttile(tl);  hold(ax,'on'); grid(ax,'on'); box(ax,'on'); set(ax,'YScale','log');
    plot_methods(ax, Tnoi.spread_dB, Tnoi, cm, '_rmse', 1, false);
    plot(ax, Tnoi.spread_dB, Tnoi.CRB3, crbStyle{:}, 'HandleVisibility', 'off');
    xlabel(ax, 'Noise-floor spread between dwells (dB)');  ylabel(ax, 'RMSE (deg)');
    title(ax, '(c) -2 dB SNR, noise-floor spread');
    title(tl, 'Fig. 7. P1 versus four three-channel baselines on the same triangle dwells');
    save_fig(f, outDir, 'fig7_comparison');
end
