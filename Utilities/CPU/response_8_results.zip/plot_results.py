"""Draws the same seven figures as plot_all in ucatri_sim_r2022.m from the CSV files."""
import pandas as pd, matplotlib, matplotlib.ticker, os
matplotlib.use('Agg'); import matplotlib.pyplot as plt
D = 'results'; rd = lambda f: pd.read_csv(os.path.join(D, f))
S = {'M1': ('--o', '#9e9e9e', 1.2, 'M1: 2-ch CI'), 'M2': ('-s', '#737373', 1.2, 'M2: 3-ch triangle CI'),
     'CIcos': ('--s', '#b07aa1', 1.2, 'CI, cosine metric [8]'), 'APCI': ('-^', '#59a14f', 1.2, 'All-pair phase CI'),
     'SSMUSIC': ('-d', '#f28e2b', 1.2, 'Subarray MUSIC [10]'), 'EP': (':v', '#8c8c8c', 1.2, 'Eigen-phase CI'),
     'UC': ('-.x', '#4d4d4d', 1.2, 'Unweighted covariance CI'), 'P1': ('-o', '#1f5fbf', 2.2, 'P1, proposed'),
     'P2': (':o', '#33a6d9', 1.4, 'P2, closed form')}
def pm(ax, x, T, names, suf, scale=1, legend=True):
    for n in names:
        ls, c, lw, lab = S[n]
        ax.plot(x, scale*T[n+suf], ls, color=c, lw=lw, ms=4, label=lab if legend else None)
def crb(ax, x, y, legend=True): ax.plot(x, y, 'k--', lw=1.2, label='CRB, triangles' if legend else None)
def save(f, name): f.tight_layout(); f.savefig(os.path.join(D, name+'.png'), dpi=200); plt.close(f)

snr, lo, hi, sig, noi, TT = rd('fig2_3_snr.csv'), rd('fig4_low.csv'), rd('fig4_high.csv'), rd('fig5_signal.csv'), rd('fig5_noise.csv'), rd('fig6_T.csv')
allm = ['M1', 'M2', 'CIcos', 'APCI', 'SSMUSIC', 'P1']

f, ax = plt.subplots(figsize=(7.6, 5)); ax.set_yscale('log'); pm(ax, snr.SNR_dB, snr, allm, '_rmse')
ax.plot(snr.SNR_dB, snr.CRB2, ':', color='#666', lw=1.2, label='CRB, 2-ch'); crb(ax, snr.SNR_dB, snr.CRB3)
ax.set(xlabel='Per-element SNR (dB)', ylabel='Azimuth RMSE (deg)', title='Fig. 2. Azimuth RMSE versus SNR (f = 0.7 GHz, N = 9, T = 32)')
ax.grid(alpha=.3, which='both'); ax.legend(fontsize=8); save(f, 'fig2_rmse_vs_snr')

f, ax = plt.subplots(figsize=(7.6, 5)); pm(ax, snr.SNR_dB, snr, allm, '_pc', 100)
ax.axhline(95, ls=':', color='#666'); ax.text(-11.8, 96, '95% correct', fontsize=8, color='#666')
ax.set(xlim=(-12, 2), ylim=(0, 102), xlabel='Per-element SNR (dB)', ylabel='Correct DF, error < 5 deg (%)', title='Fig. 3. Share of correct bearings versus SNR')
ax.grid(alpha=.3); ax.legend(fontsize=8, loc='lower right'); save(f, 'fig3_correct_df_vs_snr')

f, ax = plt.subplots(figsize=(8.6, 5)); ax.set_yscale('log'); ax.set_xscale('log'); fm = ['M2', 'APCI', 'P1', 'P2']
pm(ax, lo.f_GHz, lo, fm, '_rmse'); pm(ax, hi.f_GHz, hi, fm, '_rmse', legend=False); crb(ax, lo.f_GHz, lo.CRB3); crb(ax, hi.f_GHz, hi.CRB3, False)
ax.axvline(0.8, ls=':', color='#666'); ax.text(0.82, 6, 'Array change at 0.8 GHz', fontsize=8, color='#666')
ax.set(ylim=(0.1, 10), xlim=(0.1, 2.5), xlabel='Frequency (GHz)', ylabel='Azimuth RMSE at 0 dB (deg)', title='Fig. 4. RMSE across 0.1-2.5 GHz (R = 0.50 m below 0.8 GHz, 0.15 m above)')
ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.set_xticks([0.1, 0.2, 0.3, 0.5, 0.8, 1, 1.5, 2, 2.5]); ax.set_xticklabels(['0.1', '0.2', '0.3', '0.5', '0.8', '1', '1.5', '2', '2.5'])
ax.grid(alpha=.3, which='both'); ax.legend(fontsize=8, loc='lower left'); save(f, 'fig4_rmse_vs_frequency')

f, axs = plt.subplots(1, 2, figsize=(10.8, 4.6), sharey=True); sm = ['M2', 'EP', 'APCI', 'SSMUSIC', 'UC', 'P1']
for ax, T, xl, tt, lg in [(axs[0], sig, 'Signal-power spread between dwells (dB)', '(a) Signal-power spread', True), (axs[1], noi, 'Noise-floor spread between dwells (dB)', '(b) Noise-floor spread', False)]:
    ax.set_yscale('log'); pm(ax, T.spread_dB, T, sm, '_rmse', legend=lg); crb(ax, T.spread_dB, T.CRB3, lg); ax.set(xlabel=xl, title=tt); ax.grid(alpha=.3, which='both')
axs[0].set_ylabel('RMSE (deg)'); axs[0].legend(fontsize=8, loc='upper left')
f.suptitle('Fig. 5. Robustness to dwell-to-dwell fluctuations (-2 dB mean SNR, 0.7 GHz)'); save(f, 'fig5_fluctuations')

f, ax = plt.subplots(figsize=(7.6, 5)); ax.set_yscale('log'); ax.set_xscale('log')
pm(ax, TT['T'], TT, ['M1', 'M2', 'APCI', 'SSMUSIC', 'P1'], '_rmse'); crb(ax, TT['T'], TT.CRB3)
ax.set_xticks([8, 16, 32, 64, 128, 256]); ax.set_xticklabels(['8', '16', '32', '64', '128', '256'])
ax.set(xlabel='Snapshots per dwell T', ylabel='Azimuth RMSE at -4 dB (deg)', title='Fig. 6. RMSE versus snapshots per dwell')
ax.grid(alpha=.3, which='both'); ax.legend(fontsize=8); save(f, 'fig6_rmse_vs_snapshots')

f, axs = plt.subplots(1, 3, figsize=(13.8, 4.4)); cm = ['M2', 'CIcos', 'APCI', 'SSMUSIC', 'P1']
axs[0].set_yscale('log'); pm(axs[0], snr.SNR_dB, snr, cm, '_rmse'); crb(axs[0], snr.SNR_dB, snr.CRB3)
axs[0].set(xlabel='Per-element SNR (dB)', ylabel='RMSE (deg)', title='(a) RMSE versus SNR'); axs[0].legend(fontsize=8)
pm(axs[1], snr.SNR_dB, snr, cm, '_pc', 100, False); axs[1].axhline(95, ls=':', color='#666')
axs[1].set(xlim=(-12, 2), xlabel='Per-element SNR (dB)', ylabel='Correct DF (%)', title='(b) Share within 5 deg')
axs[2].set_yscale('log'); pm(axs[2], noi.spread_dB, noi, cm, '_rmse', legend=False); crb(axs[2], noi.spread_dB, noi.CRB3, False)
axs[2].set(xlabel='Noise-floor spread between dwells (dB)', ylabel='RMSE (deg)', title='(c) -2 dB SNR, noise-floor spread')
for ax in axs: ax.grid(alpha=.3, which='both')
f.suptitle('Fig. 7. P1 versus four three-channel baselines on the same triangle dwells'); save(f, 'fig7_comparison')
print('done')
